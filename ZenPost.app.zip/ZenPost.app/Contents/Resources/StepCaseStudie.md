Wir bauen alles als Step Situtation auf 


folgendes wird dabei gemacht 


Step01 umbau Content View 


Group {
    switch step {
    case 1: StepDropFileView()
    case 2: Step2MetaView()
    ...
    }
}
spacer ()
ZenStepNavBar(step: $step)
    }
    .padding()
    .frame(width: 520, height: 420)
    }
}

wir legen für jeden Step ein Komponente an 

- StepDropFileView.swift 
- Step2MetaView.swift 
- ...
- ZenStepNavBar.swift
- ZenStepHeader.swift



