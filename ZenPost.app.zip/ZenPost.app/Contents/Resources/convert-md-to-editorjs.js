//
//  convert-md-to-editorjs.js
//  ZenPost
//
//  Created by Denis Bitter on 07.07.25.
//


// convert-md-to-editorjs.js
const fs = require('fs');
const md = fs.readFileSync(process.argv[2], 'utf8');

// Dummy: Alles als Paragraph, Zeilenumbrüche bleiben erhalten
const blocks = md.split(/\n{2,}/).map((block, i) => ({
  id: `block${i+1}`,
  type: block.startsWith('# ') ? 'header' : 'paragraph',
  data: block.startsWith('# ')
    ? { text: block.replace(/^# /, ''), level: 2 }
    : { text: block.replace(/\n/g, '<br>') }
}));

console.log(JSON.stringify({ blocks }, null, 2));

